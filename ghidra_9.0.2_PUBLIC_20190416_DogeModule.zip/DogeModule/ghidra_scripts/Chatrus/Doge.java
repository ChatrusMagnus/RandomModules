package Chatrus;

import java.awt.Image;

import javax.swing.ImageIcon;

public class Doge {
	
	private Image doge;
	
	public Doge() {
		ImageIcon icon = new ImageIcon("data/doge.png");
		doge = icon.getImage();
	}
	
	public Image getImage() {
		return doge;
	}
}
